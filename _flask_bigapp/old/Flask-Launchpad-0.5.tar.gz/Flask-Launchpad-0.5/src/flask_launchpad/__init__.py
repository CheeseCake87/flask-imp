from .app import FlaskLaunchpad as FlaskLaunchpad
from .app import FLBlueprint as FLBlueprint

version = "0.5"
