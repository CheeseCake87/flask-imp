# Flask-Launchpad

A small auto importer to import multiple blueprints and their routes. Can also handle multiple imports of flask_restx apis.

This extension allows you to make multiple route files and not have to worry about manually importing each of them.

!BEWARE! - This is an auto importer! - This can be a security concern!
Don't get lazy and ensure you know what code you are potentially going to run. 
(don't auto import files you've not looked at)

Here's an example of how your project should look
```
Example folder structure :

project/
    - main/
        - blueprints/
            - example/
                - routes/
                    - route1.py
                    - route2.py
                - __init__.py
                - config.ini
                - models.py
            - example2/
            - example3/
        - api/
            - v1/
                - routes/
                    api_route1.py
                    api_route2.py
                - __init__.py
                - config.ini
                - models.py
        - __init__.py
        
    - venv/
    - run.py
```
```
main/__init__.py :
```
```python
from flask import Flask
from flask_launchpad import FlaskLaunchpad

# ~~ other imports

fl = FlaskLaunchpad()

def create_app():
    main = Flask(__name__)
    fl.init_app(main)
    fl.import_blueprints("blueprints")
    fl.import_apis("api")

# ~~~ other create app things
```
```
main/blueprints/example/__init__.py :
```
```python
from flask_launchpad import FLBlueprint

fl_bp = FLBlueprint()
bp = fl_bp.register()
fl_bp.import_routes("routes")
```
```
main/blueprints/example/config.ini :
```
```editorconfig
[init]
enabled = yes
version = 0.1
type = blueprint

[settings]
url_prefix = /example
template_folder = templates
static_folder = static
static_url_path = /static
```
```
main/blueprints/example/routes/route1.py :
```
```python
from .. import bp


@bp.route("/", methods=["GET"])
def index():
    """Example of route url redirect"""
    return """Working..."""
```

import_apis() from the main / init file, works much the same as the blueprint imports, although it prepends the blueprint holding folder into the URL registration.

In this example the v1 API folder with be registered against /api/v1

Here's an example of how the files should look to register APIs

```
main/api/v1/__init__.py :
```
```python
from flask_restx import Api
from flask_launchpad import FLBlueprint

fl_bl = FLBlueprint()
api_bp = fl_bl.register()
api = Api(api_bp, doc=f"/api_v1/docs")
fl_bl.import_routes()
# import_routes() defaults to a folder called routes
```
```
main/api/v1/config.ini :
```
```editorconfig
[init]
enabled = yes
version = 1.0
type = api

[settings]
url_prefix = /v1
```
```
main/api/v1/routes/api_route1.py :
```
```python
from flask_restx import Resource

from .. import api


@api.route('/')
class Test(Resource):
    def get(self):
        return "waiting"
```

Sticking to this method of blueprints and APIs will allow you to mass import route files.

It also auto imports models.py files, this does need a little more dev though.