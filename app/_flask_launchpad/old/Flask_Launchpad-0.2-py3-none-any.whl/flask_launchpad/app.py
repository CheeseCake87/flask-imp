from flask import current_app
from flask import Blueprint
from importlib import import_module
from os import path
from os import listdir
from configparser import ConfigParser
from inspect import stack


def has_illegal_chars(name: str, exception: list = None) -> bool:
    """
    Removes illegal chars from dir, there are:
    ['%', '$', '£', ' ', '#', 'readme', '__', '.py']
    """
    _illegal_characters = ['%', '$', '£', ' ', '#', 'readme', '__', '.py']
    if exception is not None:
        for value in exception:
            _illegal_characters.remove(value)
    for char in _illegal_characters:
        if char in name:
            return True
    return False


class FlaskLaunchpad(object):
    def __init__(self, app=None):
        self._app = app
        if app is not None:
            self.init_app(app)

    def init_app(self, app=None):
        if app is None:
            raise ImportError
        self._app = app

    def register_structure_folder(self, folder: str) -> None:
        """
        Registers a folder in the root path as a Flask template folder.
        :param folder: str
        :return: None
        """
        with self._app.app_context():
            structures = Blueprint(folder, folder, template_folder=f"{current_app.root_path}/{folder}")
            current_app.register_blueprint(structures)

    def import_blueprints(self, folder: str) -> None:
        """
        Looks through the passed in folder for Blueprint modules, imports them then registers them with Flask.
        The Blueprint object must be stored in a variable called bp in the __init__.py file on the Blueprint folder.
        For example:
        fl_bp = FLBlueprint() <- Import this at the top of the page.
        bp = fl_bp.register()
        fl_bp.import_routes("routes")
        :param folder: str
        :return: None
        """

        with self._app.app_context():
            blueprints_raw, blueprints_clean = listdir(f"{current_app.root_path}/{folder}/"), []
            for blueprint in blueprints_raw:
                if path.isdir(f"{current_app.root_path}/{folder}/{blueprint}"):
                    blueprints_clean.append(blueprint)

            for blueprint in blueprints_clean:
                _bp_root_folder = f"{current_app.root_path}/{folder}/{blueprint}"

                try:
                    blueprint_module = import_module(f"{current_app.name}.{folder}.{blueprint}")
                    blueprint_object = getattr(blueprint_module, "bp")
                    current_app.register_blueprint(blueprint_object)
                except AttributeError as e:
                    print(e)
                    continue

                if path.isfile(f"{_bp_root_folder}/models.py"):
                    models_module = import_module(f"{current_app.name}.{folder}.{blueprint}.models")
                    try:
                        import_object = getattr(models_module, "db")
                        import_object.init_app(current_app)
                    except AttributeError:
                        continue

    def import_apis(self, folder: str) -> None:
        """
        Looks through the passed in folder for Blueprint modules, imports them then registers them with Flask.
        This does the same as import_blueprints, but decorates the name with an api marker
        The Blueprint object must be stored in a variable called bp in the __init__.py file on the Blueprint folder.
        For example:
        fl_bp = FLBlueprint() <- Import this at the top of the page.
        api_bp = fl_bp.register()
        fl_bp.import_routes("routes")
        :param folder: str
        :return: None
        """

        with self._app.app_context():
            blueprints_raw, blueprints_clean = listdir(f"{current_app.root_path}/{folder}/"), []
            for blueprint in blueprints_raw:
                if path.isdir(f"{current_app.root_path}/{folder}/{blueprint}"):
                    blueprints_clean.append(blueprint)

            for blueprint in blueprints_clean:
                _bp_root_folder = f"{current_app.root_path}/{folder}/{blueprint}"

                try:
                    blueprint_module = import_module(f"{current_app.name}.{folder}.{blueprint}")
                    blueprint_object = getattr(blueprint_module, "api_bp")
                    current_app.register_blueprint(blueprint_object)
                except AttributeError as e:
                    continue

                if path.isfile(f"{_bp_root_folder}/models.py"):
                    models_module = import_module(f"{current_app.name}.{folder}.{blueprint}.models")
                    try:
                        import_object = getattr(models_module, "db")
                        import_object.init_app(current_app)
                    except AttributeError:
                        continue


class FLBlueprint:
    module_folder = None
    blueprint_name = None
    module_name = None

    def __init__(self):
        caller = stack()[1]
        split_module_folder = caller.filename.split("/")[:-1]
        self.module_folder = "/".join(split_module_folder)
        self.blueprint_name = caller.filename.split("/")[-3:-2][0]
        self.module_name = caller.filename.split("/")[-2:-1][0]

    def register(self):
        settings = {}
        if "config.ini" in listdir(self.module_folder):
            blueprint_config = ConfigParser()
            blueprint_config.read(f"{self.module_folder}/config.ini")
            settings.update(blueprint_config["settings"])
            if "init" in blueprint_config:
                if "enabled" in blueprint_config["init"]:
                    if not blueprint_config.getboolean("init", "enabled"):
                        return
                if "type" in blueprint_config["init"]:
                    if blueprint_config["init"]["type"] == "api":
                        new_url = f"/{self.blueprint_name}{settings['url_prefix']}"
                        settings['url_prefix'] = new_url
        return Blueprint(self.module_name, self.module_name, **settings)

    def import_routes(self, folder: str = "routes"):
        routes_raw, routes_clean = listdir(f"{self.module_folder}/{folder}"), []
        for route in routes_raw:
            if has_illegal_chars(route, exception=[".py"]):
                continue
            routes_clean.append(route.replace(".py", ""))

        for route in routes_clean:
            try:
                import_module(f"{current_app.name}.{self.blueprint_name}.{self.module_name}.{folder}.{route}")
            except ImportError:
                continue

    def config(self) -> dict:
        config = {}
        if "config.ini" in listdir(self.module_folder):
            blueprint_config = ConfigParser()
            blueprint_config.read(f"{self.module_folder}/config.ini")
            config.update(blueprint_config)
        return config
