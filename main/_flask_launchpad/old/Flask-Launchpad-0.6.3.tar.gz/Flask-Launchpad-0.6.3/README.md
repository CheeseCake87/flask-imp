# Flask-Launchpad

Flask-Launchpad is a small auto importer to import multiple blueprints and their routes + some extras. 

Can also handle multiple imports of flask_restx apis.

This extension allows you to make multiple route files and not have to worry about manually importing each of them.

!BEWARE! - This is an auto importer! - This can be a security concern!
Don't get lazy and ensure you know what code you are potentially going to run. 
(don't auto import files you've not looked at)

Check out the github for a working example:

https://github.com/CheeseCake87/Flask-Launchpad

Please also star the project <3